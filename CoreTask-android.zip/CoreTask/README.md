# CoreTask (Android, Kotlin + Jetpack Compose)

## Compilar
1. Instala Android Studio (Koala o más reciente) y abre la carpeta `CoreTask`.
2. Espera a que termine «Gradle sync» (necesita internet la primera vez).
3. Para probar: conecta tu teléfono con depuración USB y pulsa Run.
4. Para el APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
   Saldrá en `app/build/outputs/apk/debug/`.

## Qué incluye
- Notificaciones locales programadas (suenan con la app cerrada y sin internet)
- Aviso opcional 10 min antes, botones «Posponer 10 min» y «Hecha» en la notificación
- Sección «Caducadas» para tareas vencidas
- Prioridad, tareas repetidas (diaria/semanal), progreso
- Los avisos se reprograman al reiniciar el teléfono

## Notas
- Android 13+: acepta el permiso de notificaciones y, cuando se abra la pantalla de
  «Alarmas y recordatorios», permite la app para que los avisos lleguen a la hora exacta.
- Misma ID de paquete (com.coretask.app) que tu APK anterior: desinstala la versión vieja antes.
- No usa Firebase ni servidor, así que no hay notificaciones push remotas ni sincronización entre dispositivos.
