plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.coretask.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.coretask.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 8
        versionName = "2.3.0"
    }
    // Firma fija: así la huella SHA-1 no cambia y puedes actualizar la app sin desinstalarla.
    signingConfigs {
        getByName("debug") {
            storeFile = file("coretask.keystore")
            storePassword = "coretask123"
            keyAlias = "coretask"
            keyPassword = "coretask123"
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
}

// Firebase solo se activa si existe google-services.json (en la raíz del repositorio o en app/).
val rootJson = rootProject.file("../google-services.json")
val appJson = file("google-services.json")
if (rootJson.exists()) rootJson.copyTo(appJson, overwrite = true)
if (appJson.exists()) apply(plugin = "com.google.gms.google-services")
