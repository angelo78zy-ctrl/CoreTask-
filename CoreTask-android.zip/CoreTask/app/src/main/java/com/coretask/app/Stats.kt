package com.coretask.app

import java.text.SimpleDateFormat
import java.util.*

data class Ach(val emoji: String, val name: String, val desc: String, val ok: Boolean)

class Stats(log: List<Long>, now: Long) {
    val total = log.size
    val xp = total * 10
    val level = xp / 100 + 1
    val xpInLevel = xp % 100

    private fun day(ms: Long) = (ms + TimeZone.getDefault().getOffset(ms)) / 86_400_000L
    private val counts: Map<Long, Int> = log.groupingBy { day(it) }.eachCount()
    private val today = day(now)
    private fun sum(from: Long, to: Long): Int { var n = 0; for (d in from..to) n += counts[d] ?: 0; return n }
    private fun ym(ms: Long): Int {
        val c = Calendar.getInstance(); c.timeInMillis = ms
        return c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)
    }

    val todayCount = counts[today] ?: 0
    val streak = run {
        var d = if (todayCount > 0) today else today - 1
        var s = 0
        while ((counts[d] ?: 0) > 0) { s++; d-- }
        s
    }
    val bestStreak = run {
        var best = 0; var cur = 0; var prev = Long.MIN_VALUE
        counts.keys.sorted().forEach { d -> cur = if (d == prev + 1) cur + 1 else 1; best = maxOf(best, cur); prev = d }
        best
    }
    val week = (6 downTo 0).map { counts[today - it] ?: 0 }
    val weekLabels = (6 downTo 0).map { SimpleDateFormat("EEE", Locale("es")).format(Date(now - it * 86_400_000L)) }
    val weekTotal = week.sum()
    val prevWeek = sum(today - 13, today - 7)
    val activeDays = week.count { it > 0 }
    val month4 = (3 downTo 0).map { k -> sum(today - 6 - 7 * k, today - 7 * k) }
    val monthTotal = log.count { ym(it) == ym(now) }
    val prevMonth = log.count { ym(it) == ym(now) - 1 }
    private val maxDay = counts.values.maxOrNull() ?: 0
    private val early = log.any { Calendar.getInstance().apply { timeInMillis = it }.get(Calendar.HOUR_OF_DAY) < 9 }

    val achievements = listOf(
        Ach("🌱", "Primer paso", "Completa tu primera tarea", total >= 1),
        Ach("⭐", "Imparable", "Completa 10 tareas", total >= 10),
        Ach("🏆", "Maestro", "Completa 50 tareas", total >= 50),
        Ach("🔥", "Racha de 3", "3 días seguidos completando tareas", bestStreak >= 3),
        Ach("🚀", "Racha de 7", "Una semana seguida", bestStreak >= 7),
        Ach("🌋", "Racha de 30", "Un mes seguido", bestStreak >= 30),
        Ach("🌅", "Madrugador", "Completa una tarea antes de las 9:00", early),
        Ach("💎", "Día perfecto", "Completa 5 tareas en un solo día", maxDay >= 5),
        Ach("🎀", "Coco con moño", "Llega al nivel 3", level >= 3),
        Ach("👑", "Coco real", "Llega al nivel 5", level >= 5)
    )
}
