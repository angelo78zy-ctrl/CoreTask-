package com.coretask.app

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

data class Diag(val notif: Boolean, val exact: Boolean, val battery: Boolean)

// Revisa y ayuda a arreglar lo que suele impedir que lleguen los avisos.
object Notif {
    fun read(c: Context): Diag {
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = nm.getNotificationChannel(Reminders.CHANNEL)
        val notif = nm.areNotificationsEnabled() && (ch == null || ch.importance != NotificationManager.IMPORTANCE_NONE)
        val battery = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
        return Diag(notif, Reminders.canExact(c), battery)
    }

    private fun go(c: Context, i: Intent, fallback: Intent? = null) {
        try { c.startActivity(i) } catch (e: Exception) {
            try { if (fallback != null) c.startActivity(fallback) } catch (e2: Exception) { }
        }
    }

    private fun pkg(c: Context) = Uri.parse("package:" + c.packageName)

    fun openApp(c: Context) = go(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg(c)))

    fun openNotif(c: Context) = go(c,
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName),
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg(c)))

    fun openExact(c: Context) {
        if (Build.VERSION.SDK_INT >= 31) go(c, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkg(c)),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg(c)))
    }

    fun openBattery(c: Context) = go(c,
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg(c)),
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
}

@Composable
fun DiagRow(label: String, ok: Boolean, action: String, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(if (ok) "✅" else "⚠️", fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Text(label, color = Pal.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        if (!ok) Chunky(Modifier, Pal.orange, Color(0xFFB45309), 14.dp, onClick = onFix) {
            Text(action, color = Pal.bg, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun NotifPanel() {
    val c = LocalContext.current
    var d by remember { mutableStateOf(Notif.read(c)) }
    var msg by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { while (true) { d = Notif.read(c); delay(1500) } }
    Panel(Modifier.fillMaxWidth(), radius = 28.dp) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("🔔 Notificaciones", color = Pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Si los avisos no llegan, revisa estos puntos:", color = Pal.muted, fontSize = 13.sp)
            DiagRow("Notificaciones permitidas", d.notif, "Activar") { Notif.openNotif(c) }
            DiagRow("Alarmas exactas", d.exact, "Activar") { Notif.openExact(c) }
            DiagRow("Batería sin restricciones", d.battery, "Permitir") { Notif.openBattery(c) }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chunky(Modifier.weight(1f), Pal.blue, Pal.blueDark, onClick = {
                    Reminders.notifyTest(c); msg = "Si no ves la notificación ahora, están bloqueadas."
                }) { Text("Probar ahora", color = Color.White, fontWeight = FontWeight.Bold) }
                Chunky(Modifier.weight(1f), Pal.blue, Pal.blueDark, onClick = {
                    Reminders.scheduleTest(c); msg = "Cierra la app por completo: en 1 minuto debe sonar."
                }) { Text("Probar en 1 min", color = Color.White, fontWeight = FontWeight.Bold) }
            }
            Chunky(Modifier.fillMaxWidth(), Pal.surface2, Pal.border, onClick = { Notif.openApp(c) }) {
                Text("Abrir ajustes de la app", color = Pal.text, fontWeight = FontWeight.Bold)
            }
            Text(
                "En Xiaomi, Oppo, Realme, Vivo, Huawei y Samsung también activa «Inicio automático» " +
                    "(o «Permitir actividad en segundo plano») y bloquea la app en recientes.",
                color = Pal.muted, fontSize = 12.sp
            )
            if (msg.isNotEmpty()) Text(msg, color = Pal.accent, fontSize = 13.sp)
        }
    }
}
