package com.coretask.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object Pal {
    val bg = Color(0xFF0A1420)
    val surface = Color(0xFF152030)
    val surface2 = Color(0xFF1B2A3E)
    val border = Color(0xFF263A55)
    val text = Color(0xFFF1F5F9)
    val muted = Color(0xFF94A3B8)
    val accent = Color(0xFF22B5F5)
    val accentDark = Color(0xFF0E86C0)
    val accentBg = Color(0xFF0C3D52)
    val blue = Color(0xFF3B82F6)
    val blueDark = Color(0xFF1D4ED8)
    val blueText = Color(0xFF60A5FA)
    val blueBg = Color(0xFF17305A)
    val red = Color(0xFFEF4444)
    val redSoft = Color(0xFFFFE4E6)
    val redBg = Color(0xFF3A1A22)
    val orange = Color(0xFFFB923C)
    val orangeBg = Color(0xFF3D2410)
    val green = Color(0xFF34D399)
    val greenBg = Color(0xFF0F3D33)
    val purple = Color(0xFFA78BFA)
    val purpleBg = Color(0xFF2A2250)
}

// Tarjeta oscura con borde.
@Composable
fun Panel(
    modifier: Modifier = Modifier, radius: Dp = 24.dp, borderColor: Color = Pal.border, fill: Color = Pal.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Column(modifier.clip(shape).background(fill).border(2.dp, borderColor, shape), content = content)
}

// Botón "gordito" con canto inferior más oscuro (efecto 3D).
@Composable
fun Chunky(
    modifier: Modifier = Modifier, color: Color, edge: Color, radius: Dp = 18.dp, fill: Boolean = false,
    onClick: (() -> Unit)? = null, content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    val base = modifier.clip(shape).background(edge)
    Box(if (onClick != null) base.clickable(onClick = onClick) else base) {
        Box(
            Modifier.padding(bottom = 5.dp).let { if (fill) it.fillMaxSize() else it }
                .clip(shape).background(color)
                .let { if (fill) it else it.padding(horizontal = 18.dp, vertical = 12.dp) },
            contentAlignment = Alignment.Center, content = content
        )
    }
}

@Composable
fun Chip(text: String, fg: Color, bg: Color, icon: String? = null) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Text(icon, fontSize = 12.sp); Spacer(Modifier.width(4.dp)) }
        Text(text.uppercase(), color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
    }
}

@Composable
fun SectionHeader(title: String, color: Color, count: Int) {
    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(8.dp).height(30.dp).clip(RoundedCornerShape(4.dp)).background(color))
        Spacer(Modifier.width(10.dp))
        Text(title, color = Pal.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = .2f)).padding(horizontal = 12.dp, vertical = 4.dp)) {
            Text("$count", color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun Mini(emoji: String, value: String, label: String, modifier: Modifier) {
    Panel(modifier, radius = 20.dp, fill = Pal.surface2) {
        Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 20.sp)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Pal.text)
            Text(label.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Pal.muted, letterSpacing = 0.5.sp)
        }
    }
}

// Categorías de las tareas.
val categories = listOf("Personal", "Trabajo", "Estudio", "Salud", "Hogar", "Otro")
val categoryColors = listOf(Pal.accent, Pal.blueText, Pal.orange, Pal.green, Pal.purple, Pal.muted)
val categoryBg = listOf(Pal.accentBg, Pal.blueBg, Pal.orangeBg, Pal.greenBg, Pal.purpleBg, Pal.surface2)

fun prioColors(p: Int): Pair<Color, Color> = when (p) {
    2 -> Pal.red to Pal.redBg
    1 -> Pal.blueText to Pal.blueBg
    else -> Pal.green to Pal.greenBg
}
