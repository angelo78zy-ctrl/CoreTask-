package com.coretask.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object Reminders {
    const val CHANNEL = "tasks"
    const val ACT_SNOOZE = "com.coretask.SNOOZE"
    const val ACT_DONE = "com.coretask.DONE"
    const val ACT_TEST = "com.coretask.TEST"
    private const val FLAGS = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun alarmIntent(c: Context, id: Long) = PendingIntent.getBroadcast(
        c, id.toInt(), Intent(c, AlarmReceiver::class.java).putExtra("id", id), FLAGS)

    fun cancel(c: Context, id: Long) {
        c.getSystemService(AlarmManager::class.java).cancel(alarmIntent(c, id))
    }

    fun schedule(c: Context, t: Task) {
        cancel(c, t.id)
        val at = t.due - t.lead * 60_000L
        if (t.done || t.due == 0L || at <= System.currentTimeMillis()) return
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = alarmIntent(c, t.id)
        if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    // Completa una tarea; si se repite, pasa a la siguiente ocurrencia en vez de cerrarse.
    fun finish(c: Context, id: Long) {
        val t = Store.update(c, id) { t ->
            if (t.repeat > 0 && t.due > 0) {
                val step = if (t.repeat == 1) 86_400_000L else 604_800_000L
                var d = t.due
                do { d += step } while (d <= System.currentTimeMillis())
                t.copy(due = d)
            } else t.copy(done = true)
        } ?: return
        Store.addLog(c, id)
        schedule(c, t)
    }

    private fun manager(c: Context): NotificationManager {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Recordatorios", NotificationManager.IMPORTANCE_HIGH))
        return nm
    }

    fun canExact(c: Context) = Build.VERSION.SDK_INT < 31 || c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    // Notificación de prueba inmediata.
    fun notifyTest(c: Context) {
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("CoreTask funciona ✅")
            .setContentText("Si ves esto, las notificaciones están bien.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        manager(c).notify(999_999, n)
    }

    // Prueba con la app cerrada: suena dentro de 1 minuto usando el mismo mecanismo que las tareas.
    fun scheduleTest(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(c, 999, Intent(c, AlarmReceiver::class.java).setAction(ACT_TEST), FLAGS)
        val at = System.currentTimeMillis() + 60_000
        if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun notify(c: Context, t: Task) {
        val nm = manager(c)
        fun action(a: String) = PendingIntent.getBroadcast(
            c, t.id.toInt(), Intent(c, AlarmReceiver::class.java).setAction(a).putExtra("id", t.id), FLAGS)
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val early = t.due - System.currentTimeMillis() > 60_000
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(t.title)
            .setContentText(if (early) "Vence en ${t.lead} min" else "Es la hora de esta tarea")
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "Posponer 10 min", action(ACT_SNOOZE))
            .addAction(0, "Hecha", action(ACT_DONE))
            .build()
        nm.notify(t.id.toInt(), n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", 0L)
        val nm = c.getSystemService(NotificationManager::class.java)
        when (i.action) {
            Reminders.ACT_SNOOZE -> {
                nm.cancel(id.toInt())
                Store.update(c, id) { it.copy(due = System.currentTimeMillis() + 600_000, lead = 0) }
                    ?.let { Reminders.schedule(c, it) }
            }
            Reminders.ACT_DONE -> { nm.cancel(id.toInt()); Reminders.finish(c, id) }
            Reminders.ACT_TEST -> Reminders.notifyTest(c)
            else -> Store.load(c).find { it.id == id && !it.done }?.let { Reminders.notify(c, it) }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.load(c).forEach { Reminders.schedule(c, it) }
    }
}
