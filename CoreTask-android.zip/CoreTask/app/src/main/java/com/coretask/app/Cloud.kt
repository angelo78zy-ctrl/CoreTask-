package com.coretask.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.util.Base64
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

private suspend fun <T> com.google.android.gms.tasks.Task<T>.await2(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { cont.resume(it) }
    addOnFailureListener { cont.resumeWithException(it) }
}

// Copia de seguridad manual y mezcla de datos (se usa también para la nube).
object Backup {
    fun fields(s: Snap): Map<String, String> = mapOf(
        "tasks" to Store.tasksToString(s.tasks),
        "log" to Store.logToString(s.log),
        "seen" to org.json.JSONArray(s.seen.toList()).toString(),
        "deleted" to org.json.JSONArray(s.deleted.toList()).toString()
    )

    fun fromFields(get: (String) -> String?): Snap = Snap(
        Store.tasksFrom(get("tasks")), Store.logFrom(get("log")),
        Store.stringsFrom(get("seen")).toSet(), Store.longsFrom(get("deleted")).toSet()
    )

    // Une dos copias sin perder nada. Si una tarea está hecha en alguna, queda hecha.
    fun merge(local: Snap, other: Snap): Snap {
        val del = local.deleted + other.deleted
        val byId = LinkedHashMap<Long, Task>()
        for (t in other.tasks) byId[t.id] = t
        for (t in local.tasks) {
            val o = byId[t.id]
            byId[t.id] = if (o != null && o.done && !t.done) o else t
        }
        return Snap(
            byId.values.filter { it.id !in del },
            (local.log + other.log).distinct().sortedBy { it.first },
            local.seen + other.seen, del
        )
    }

    fun export(c: Context): String {
        val o = JSONObject()
        for ((k, v) in fields(Store.snapshot(c))) o.put(k, v)
        return "CORETASK1:" + Base64.encodeToString(o.toString().toByteArray(), Base64.NO_WRAP)
    }

    fun parse(code: String): Snap? = try {
        val raw = code.trim().removePrefix("CORETASK1:")
        val o = JSONObject(String(Base64.decode(raw, Base64.DEFAULT)))
        if (!o.has("tasks")) null else fromFields { o.optString(it, "") }
    } catch (e: Exception) { null }

    fun share(c: Context): String {
        val code = export(c)
        try {
            c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("CoreTask", code))
        } catch (e: Exception) { }
        val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, code) }
        c.startActivity(Intent.createChooser(send, "Guardar copia de seguridad"))
        return "Código copiado. Guárdalo en un lugar seguro (notas, correo…)."
    }

    fun code(c: Context): String = export(c)

    fun restore(c: Context, text: String): Boolean {
        val snap = parse(text) ?: return false
        Store.apply(c, merge(Store.snapshot(c), snap))
        return true
    }

    fun clipboardText(c: Context): String = try {
        c.getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.coerceToText(c)?.toString() ?: ""
    } catch (e: Exception) { "" }
}

object Cloud {
    private var synced = false
    private var lastPushed = ""

    fun ready(c: Context) = FirebaseApp.getApps(c).isNotEmpty()
    fun user(): FirebaseUser? = try { FirebaseAuth.getInstance().currentUser } catch (e: Exception) { null }
    fun label(): String? = user()?.let { it.displayName ?: it.email }

    // Devuelve null si todo salió bien, o un mensaje de error.
    suspend fun signIn(ctx: Context): String? {
        synced = false
        val id = ctx.resources.getIdentifier("default_web_client_id", "string", ctx.packageName)
        if (id == 0 || !ready(ctx)) return "Falta configurar Firebase (archivo google-services.json)."
        return try {
            val option = GetSignInWithGoogleOption.Builder(ctx.getString(id)).build()
            val req = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val cred = CredentialManager.create(ctx).getCredential(ctx, req).credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                FirebaseAuth.getInstance().signInWithCredential(GoogleAuthProvider.getCredential(g.idToken, null)).await2()
                null
            } else "No se pudo leer la cuenta de Google."
        } catch (e: Exception) {
            "No se pudo iniciar sesión: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    suspend fun signOut(ctx: Context) {
        synced = false
        lastPushed = ""
        try { if (ready(ctx)) FirebaseAuth.getInstance().signOut() } catch (e: Exception) { }
        try { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) } catch (e: Exception) { }
    }

    // Sincroniza sin bloquear: avisa con un mensaje cuando termina.
    fun pull(c: Context, onDone: (String) -> Unit) {
        CoroutineScope(Dispatchers.Main).launch { onDone(sync(c)) }
    }

    // Sube los cambios locales (solo si ya se sincronizó una vez y algo cambió).
    fun autoPush(c: Context) {
        if (!synced) return
        val u = user() ?: return
        val f = Backup.fields(Store.snapshot(c))
        val key = f.toString()
        if (key == lastPushed) return
        lastPushed = key
        try { FirebaseFirestore.getInstance().collection("users").document(u.uid).set(f) } catch (e: Exception) { }
    }

    // Descarga lo de la nube, lo mezcla con lo local y guarda el resultado en ambos lados.
    suspend fun sync(c: Context): String {
        val u = user() ?: return "Inicia sesión para sincronizar."
        val ref = FirebaseFirestore.getInstance().collection("users").document(u.uid)
        val doc = try { withTimeoutOrNull(15000) { ref.get().await2() } } catch (e: Exception) { null }
            ?: return "No se pudo conectar. Inténtalo de nuevo con internet."
        val cloud = if (doc.exists()) Backup.fromFields { doc.getString(it) } else null
        val merged = if (cloud == null) Store.snapshot(c) else Backup.merge(Store.snapshot(c), cloud)
        if (cloud != null) Store.apply(c, merged)
        val f = Backup.fields(merged)
        lastPushed = f.toString()
        synced = true
        ref.set(f)
        return "Sincronizado ✅"
    }
}
