package com.coretask.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// priority: 0 baja, 1 media, 2 alta · repeat: 0 una vez, 1 diaria, 2 semanal · lead: minutos de aviso previo
data class Task(
    val id: Long, val title: String, val due: Long,
    val priority: Int, val repeat: Int, val lead: Int, val done: Boolean, val category: Int = 0
)

// Todo lo que se guarda en la nube o en una copia de seguridad.
data class Snap(val tasks: List<Task>, val log: List<Pair<Long, Long>>, val seen: Set<String>, val deleted: Set<Long>)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    private fun arr(s: String?) = JSONArray(if (s.isNullOrBlank()) "[]" else s)

    fun tasksToString(list: List<Task>): String {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("due", it.due)
                .put("priority", it.priority).put("repeat", it.repeat).put("lead", it.lead).put("done", it.done).put("category", it.category))
        }
        return a.toString()
    }

    fun tasksFrom(s: String?): List<Task> {
        val a = arr(s)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Task(o.getLong("id"), o.getString("title"), o.getLong("due"), o.getInt("priority"),
                o.getInt("repeat"), o.getInt("lead"), o.getBoolean("done"), o.optInt("category", 0))
        }
    }

    fun logToString(l: List<Pair<Long, Long>>): String {
        val a = JSONArray()
        l.forEach { a.put("${it.first}:${it.second}") }
        return a.toString()
    }

    fun logFrom(s: String?): List<Pair<Long, Long>> {
        val a = arr(s)
        return (0 until a.length()).map { val p = a.getString(it).split(":"); p[0].toLong() to p[1].toLong() }
    }

    fun stringsFrom(s: String?): List<String> { val a = arr(s); return (0 until a.length()).map { a.getString(it) } }
    fun longsFrom(s: String?): List<Long> { val a = arr(s); return (0 until a.length()).map { a.getLong(it) } }

    fun load(c: Context): List<Task> = tasksFrom(prefs(c).getString("tasks", "[]"))
    fun save(c: Context, list: List<Task>) { prefs(c).edit().putString("tasks", tasksToString(list)).apply() }

    fun update(c: Context, id: Long, f: (Task) -> Task): Task? {
        var result: Task? = null
        save(c, load(c).map { if (it.id == id) f(it).also { n -> result = n } else it })
        return result
    }

    // Historial de tareas completadas: pares (momento, idTarea). Alimenta racha, progreso y logros.
    fun log(c: Context): List<Pair<Long, Long>> = logFrom(prefs(c).getString("log", "[]"))
    private fun saveLog(c: Context, l: List<Pair<Long, Long>>) { prefs(c).edit().putString("log", logToString(l)).apply() }
    fun addLog(c: Context, id: Long) = saveLog(c, log(c) + (System.currentTimeMillis() to id))
    fun removeLog(c: Context, id: Long) {
        val l = log(c).toMutableList()
        val i = l.indexOfLast { it.second == id }
        if (i >= 0) { l.removeAt(i); saveLog(c, l) }
    }

    fun seen(c: Context): Set<String> = prefs(c).getStringSet("seen", emptySet())?.toSet() ?: emptySet()
    fun deleted(c: Context): Set<Long> = longsFrom(prefs(c).getString("deleted", "[]")).toSet()
    fun markDeleted(c: Context, id: Long) {
        prefs(c).edit().putString("deleted", JSONArray((deleted(c) + id).toList()).toString()).apply()
    }

    fun snapshot(c: Context) = Snap(load(c), log(c), seen(c), deleted(c))

    fun apply(c: Context, s: Snap) {
        val keep = s.tasks.map { it.id }.toSet()
        load(c).filter { it.id !in keep }.forEach { Reminders.cancel(c, it.id) }
        save(c, s.tasks)
        saveLog(c, s.log)
        prefs(c).edit()
            .putStringSet("seen", s.seen)
            .putString("deleted", JSONArray(s.deleted.toList()).toString())
            .apply()
        s.tasks.forEach { Reminders.schedule(c, it) }
    }
}
