package com.coretask.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

// priority: 0 baja, 1 media, 2 alta · repeat: 0 una vez, 1 diaria, 2 semanal · lead: minutos de aviso previo
data class Task(
    val id: Long, val title: String, val due: Long,
    val priority: Int, val repeat: Int, val lead: Int, val done: Boolean
)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)

    fun load(c: Context): List<Task> {
        val a = JSONArray(prefs(c).getString("tasks", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Task(o.getLong("id"), o.getString("title"), o.getLong("due"), o.getInt("priority"),
                o.getInt("repeat"), o.getInt("lead"), o.getBoolean("done"))
        }
    }

    fun save(c: Context, list: List<Task>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("due", it.due)
                .put("priority", it.priority).put("repeat", it.repeat).put("lead", it.lead).put("done", it.done))
        }
        prefs(c).edit().putString("tasks", a.toString()).apply()
    }

    fun update(c: Context, id: Long, f: (Task) -> Task): Task? {
        var result: Task? = null
        save(c, load(c).map { if (it.id == id) f(it).also { n -> result = n } else it })
        return result
    }
}
