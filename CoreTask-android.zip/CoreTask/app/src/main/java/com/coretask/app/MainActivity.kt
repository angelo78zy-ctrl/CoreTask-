package com.coretask.app

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val repeats = listOf("Una vez", "Diaria", "Semanal")
private val priorities = listOf("Baja", "Media", "Alta")
private fun fmt(ms: Long) = SimpleDateFormat("EEE d MMM, HH:mm", Locale("es")).format(Date(ms))
private fun plural(n: Int, s: String) = "$n $s" + if (n == 1) "" else "s"

private fun askExactAlarm(c: Context) {
    val p = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    if (p.getBoolean("askedExact", false)) return
    p.edit().putBoolean("askedExact", true).apply()
    if (Build.VERSION.SDK_INT >= 31 && !c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms())
        c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + c.packageName)))
}

private fun pick(c: Context, onDone: (Long) -> Unit) {
    val cal = Calendar.getInstance()
    DatePickerDialog(c, { _, y, m, d ->
        TimePickerDialog(c, { _, h, min ->
            cal.set(y, m, d, h, min, 0); cal.set(Calendar.MILLISECOND, 0)
            onDone(cal.timeInMillis)
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
}

@Composable
fun App() {
    val c = LocalContext.current
    val prefs = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    var tasks by remember { mutableStateOf(Store.load(c)) }
    var log by remember { mutableStateOf(Store.log(c).map { it.first }) }
    var adding by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var celebrateAt by remember { mutableLongStateOf(0L) }
    var tab by remember { mutableIntStateOf(0) }
    var account by remember { mutableStateOf(Cloud.label()) }
    var status by remember { mutableStateOf("") }
    var importing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var seen by remember { mutableStateOf<Set<String>>(prefs.getStringSet("seen", emptySet()) ?: emptySet()) }

    fun refresh() {
        tasks = Store.load(c)
        log = Store.log(c).map { it.first }
        now = System.currentTimeMillis()
        seen = prefs.getStringSet("seen", emptySet()) ?: emptySet()
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { askExactAlarm(c) }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else askExactAlarm(c)
    }
    LaunchedEffect(Unit) {
        if (Cloud.user() != null) Cloud.pull(c) { status = it; refresh() }
        while (true) { delay(2000); refresh(); Cloud.autoPush(c) }
    }

    val toggle = { t: Task ->
        if (!t.done) {
            Reminders.finish(c, t.id)
            celebrateAt = System.currentTimeMillis()
        } else {
            Store.removeLog(c, t.id)
            Store.update(c, t.id) { it.copy(done = false) }?.let { Reminders.schedule(c, it) }
        }
        refresh()
    }
    val delete = { t: Task ->
        Reminders.cancel(c, t.id)
        Store.save(c, Store.load(c).filter { it.id != t.id })
        Store.markDeleted(c, t.id)
        refresh()
    }

    val signIn: () -> Unit = {
        scope.launch {
            status = "Conectando…"
            val err = Cloud.signIn(c)
            if (err == null) {
                account = Cloud.label()
                Cloud.pull(c) { status = it; refresh() }
            } else status = err
        }
    }
    val signOut: () -> Unit = {
        scope.launch { Cloud.signOut(c); account = null; status = "Sesión cerrada" }
    }
    val sync: () -> Unit = {
        status = "Sincronizando…"
        Cloud.pull(c) { status = it; refresh() }
    }
    val export: () -> Unit = {
        val code = Backup.code(c)
        c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("CoreTask", code))
        status = "Código copiado al portapapeles ✅"
        c.startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code), "Guardar copia de seguridad"))
    }

    val stats = remember(log, now) { Stats(log, now) }
    val late = tasks.filter { !it.done && it.due in 1 until now }.sortedBy { it.due }
    val open = tasks.filter { !it.done && !(it.due in 1 until now) }
        .sortedWith(compareBy({ it.due == 0L }, { it.due }, { -it.priority }))
    val done = tasks.filter { it.done }

    val celebrating = now - celebrateAt < 5000
    val mood = when {
        late.isNotEmpty() && !celebrating -> 2
        celebrating || stats.todayCount > 0 -> 1
        else -> 0
    }
    val msg = when {
        celebrating -> "¡Bien hecho! +10 XP 🎉"
        late.isNotEmpty() -> "Tienes ${plural(late.size, "tarea")} caducada${if (late.size == 1) "" else "s"}… ¡tú puedes! 🥺"
        tasks.isEmpty() -> "¡Hola! Soy Coco 💜 Agrega tu primera tarea."
        stats.streak >= 2 -> "¡Llevas ${stats.streak} días de racha! 🔥"
        open.isNotEmpty() -> "Hoy puedes con ${plural(open.size, "tarea")} 💪"
        else -> "¡Todo listo! Hora de descansar 😴"
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF6C5CE7), secondary = Color(0xFFFF8FB1))) {
        Box(Modifier.fillMaxSize()) {
            AnimatedBackground()
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    NavigationBar(
                        modifier = Modifier.clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
                        containerColor = Color.White.copy(alpha = .85f)
                    ) {
                        listOf("🏠" to "Tareas", "📈" to "Progreso", "🏅" to "Logros", "👤" to "Cuenta").forEachIndexed { i, (e, n) ->
                            NavigationBarItem(tab == i, { tab = i }, { Text(e, fontSize = 22.sp) }, label = { Text(n) },
                                colors = NavigationBarItemDefaults.colors(indicatorColor = Color(0xFFFFD6E5)))
                        }
                    }
                },
                floatingActionButton = {
                    if (tab == 0) ExtendedFloatingActionButton(
                        onClick = { adding = true },
                        shape = CircleShape, containerColor = Color(0xFFFF6FA5), contentColor = Color.White
                    ) { Text("✨ Nueva tarea") }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    when (tab) {
                        0 -> TasksTab(late, open, done, stats, mood, msg, toggle, delete)
                        1 -> ProgressTab(stats)
                        2 -> AchTab(stats)
                        else -> AccountTab(account, status, signIn, sync, signOut, export) { importing = true }
                    }
                }
            }
        }
        if (adding) AddDialog(onDismiss = { adding = false }) { t ->
            Store.save(c, Store.load(c) + t)
            Reminders.schedule(c, t)
            refresh()
            adding = false
        }
        if (importing) ImportDialog(onDismiss = { importing = false }) { text ->
            val ok = Backup.restore(c, text)
            status = if (ok) "Copia importada ✅" else "Código no válido"
            importing = false
            refresh()
        }
        val pending = stats.achievements.filter { it.ok && it.name !in seen }
        if (pending.isNotEmpty()) AlertDialog(
            onDismissRequest = {},
            title = { Text("¡Logro desbloqueado! 🎉") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    pending.forEach { Text("${it.emoji} ${it.name}", fontWeight = FontWeight.Bold); Text(it.desc) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    seen = seen + pending.map { it.name }
                    prefs.edit().putStringSet("seen", seen).apply()
                }) { Text("¡Genial!") }
            }
        )
    }
}

@Composable
fun GradCard(colors: List<Color>, modifier: Modifier = Modifier, radius: Dp = 26.dp, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(radius)
    Column(
        modifier.shadow(6.dp, shape, ambientColor = colors.last(), spotColor = colors.first())
            .clip(shape).background(Brush.linearGradient(colors)),
        content = content
    )
}

private val ink = Color(0xFF2B2250)

@Composable
fun TasksTab(
    late: List<Task>, open: List<Task>, done: List<Task>, s: Stats, mood: Int, msg: String,
    onToggle: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(132.dp).background(Brush.radialGradient(listOf(Color(0xAAFFFFFF), Color.Transparent)), CircleShape)) {
                    Mascot(mood, s.level, Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(4.dp))
                Column(Modifier.weight(1f)) {
                    GradCard(listOf(Color.White, Color(0xFFFFEAF3)), Modifier.fillMaxWidth()) {
                        Text(msg, Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium, color = ink)
                    }
                    Spacer(Modifier.height(8.dp))
                    GradCard(listOf(Color(0xFF8E7CFF), Color(0xFFFF8FB1)), Modifier.fillMaxWidth(), 20.dp) {
                        Column(Modifier.padding(10.dp)) {
                            Text("Nivel ${s.level} · ${s.xpInLevel}/50 XP", color = Color.White, fontWeight = FontWeight.Bold)
                            val p by animateFloatAsState(s.xpInLevel / 50f, label = "xp")
                            LinearProgressIndicator(
                                progress = { p },
                                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).height(8.dp).clip(RoundedCornerShape(8.dp)),
                                color = Color.White, trackColor = Color(0x55FFFFFF)
                            )
                            Text("🔥 Racha: ${plural(s.streak, "día")}", color = Color.White)
                        }
                    }
                }
            }
        }
        section("⚠️ Caducadas", Color(0xFFFF6B8A), late, true, onToggle, onDelete)
        section("📝 Pendientes", Color(0xFF6C5CE7), open, false, onToggle, onDelete)
        section("✅ Hechas", Color(0xFF2FBF8F), done, false, onToggle, onDelete)
        item { Spacer(Modifier.height(88.dp)) }
    }
}

private fun LazyListScope.section(
    title: String, pill: Color, list: List<Task>, late: Boolean, onToggle: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    if (list.isEmpty()) return
    item {
        Text(title,
            Modifier.padding(top = 6.dp).clip(RoundedCornerShape(50)).background(pill).padding(horizontal = 14.dp, vertical = 5.dp),
            color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
    }
    items(list, key = { it.id }) { t -> TaskRow(t, late, { onToggle(t) }, { onDelete(t) }) }
}

@Composable
fun TaskRow(t: Task, late: Boolean, onToggle: () -> Unit, onDelete: () -> Unit) {
    val colors = when {
        t.done -> listOf(Color(0xFFF3F3F8), Color(0xFFE6E6F0))
        late -> listOf(Color(0xFFFFE0E6), Color(0xFFFFA9BC))
        t.priority == 2 -> listOf(Color(0xFFFFE6EE), Color(0xFFFFC4D8))
        t.priority == 1 -> listOf(Color(0xFFFFF5DE), Color(0xFFFFE2AE))
        else -> listOf(Color(0xFFE8FFF4), Color(0xFFC5F5DE))
    }
    val badge = when {
        t.done -> "✅"
        late -> "⏰"
        t.priority == 2 -> "🔥"
        t.priority == 1 -> "⭐"
        else -> "🌿"
    }
    GradCard(colors, Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                t.done, { onToggle() },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF2FBF8F), uncheckedColor = Color(0xFF8E7CFF))
            )
            Box(Modifier.size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = .75f)), contentAlignment = Alignment.Center) {
                Text(badge, fontSize = 20.sp)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text(t.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, color = ink,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null)
                val meta = listOfNotNull(
                    if (t.due > 0) "⏰ " + fmt(t.due) else null,
                    if (t.repeat > 0) "🔁 " + repeats[t.repeat].lowercase() else null,
                    if (t.lead > 0) "🔔 ${t.lead} min antes" else null
                ).joinToString("  ")
                if (meta.isNotEmpty()) Text((if (late) "⚠️ Caducada · " else "") + meta,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (late) Color(0xFFB0203F) else Color(0xFF6B6485))
            }
            TextButton(onClick = onDelete) { Text("🗑️") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressTab(s: Stats) {
    var month by remember { mutableStateOf(false) }
    val vals = if (month) s.month4 else s.week
    val labels = if (month) listOf("−3 sem", "−2 sem", "−1 sem", "Esta") else s.weekLabels
    val total = if (month) s.monthTotal else s.weekTotal
    val prev = if (month) s.prevMonth else s.prevWeek
    val top = maxOf(1, vals.max())
    val d = total - prev
    val unit = if (month) "el mes" else "la semana"
    val chip = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFF8FB1), selectedLabelColor = Color.White)
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Tu progreso", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ink)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(!month, { month = false }, { Text("Semana") }, colors = chip)
            FilterChip(month, { month = true }, { Text("Mes") }, colors = chip)
        }
        GradCard(listOf(Color(0xFF8E7CFF), Color(0xFFFF8FB1)), Modifier.fillMaxWidth(), 28.dp) {
            Column(Modifier.padding(18.dp)) {
                Text("$total", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(if (month) "tareas completadas este mes" else "tareas completadas en 7 días", color = Color.White)
                Text(
                    when {
                        d > 0 -> "▲ $d más que $unit anterior 🎉"
                        d < 0 -> "▼ ${-d} menos que $unit anterior. ¡Tú puedes!"
                        else -> "Igual que $unit anterior"
                    },
                    style = MaterialTheme.typography.bodySmall, color = Color.White
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().height(170.dp), verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceEvenly) {
                    vals.forEachIndexed { i, v ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$v", style = MaterialTheme.typography.labelMedium, color = Color.White)
                            Box(Modifier.width(26.dp).height((110.dp * v / top).coerceAtLeast(5.dp)).background(
                                Brush.verticalGradient(listOf(Color.White, Color(0xFFFFD1E3))), RoundedCornerShape(10.dp)))
                            Text(labels[i], style = MaterialTheme.typography.labelSmall, color = Color.White)
                        }
                    }
                }
                Text(if (month) "Últimas 4 semanas" else "Últimos 7 días", style = MaterialTheme.typography.labelSmall, color = Color.White)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Mini("🔥", "${s.streak}", "Racha", Modifier.weight(1f), listOf(Color(0xFFFFE9C2), Color(0xFFFFC27A)))
            Mini("🏅", "${s.bestStreak}", "Mejor racha", Modifier.weight(1f), listOf(Color(0xFFE9E0FF), Color(0xFFC7B6FF)))
            Mini("📅", "${s.activeDays}/7", "Días activos", Modifier.weight(1f), listOf(Color(0xFFD6F3FF), Color(0xFFA9E2FA)))
        }
        Mini("⭐", "${s.total}", "Tareas completadas en total", Modifier.fillMaxWidth(), listOf(Color(0xFFFFE0EC), Color(0xFFFFB5D0)))
    }
}

@Composable
fun Mini(emoji: String, value: String, label: String, modifier: Modifier, colors: List<Color>) {
    GradCard(colors, modifier, 22.dp) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 22.sp)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = ink)
            Text(label, style = MaterialTheme.typography.labelSmall, color = ink)
        }
    }
}

@Composable
fun AchTab(s: Stats) {
    val got = s.achievements.count { it.ok }
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Text("Logros", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ink)
            Text("$got de ${s.achievements.size} desbloqueados", color = ink)
            LinearProgressIndicator(
                progress = { got / s.achievements.size.toFloat() },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(10.dp).clip(RoundedCornerShape(8.dp)),
                color = Color(0xFFFF6FA5), trackColor = Color(0x66FFFFFF)
            )
        }
        items(s.achievements) { a ->
            GradCard(
                if (a.ok) listOf(Color(0xFFFFF1C9), Color(0xFFFFD1E8)) else listOf(Color(0xFFF0F0F6), Color(0xFFE2E2EC)),
                Modifier.fillMaxWidth().alpha(if (a.ok) 1f else .6f)
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (a.ok) a.emoji else "🔒", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(a.name, fontWeight = FontWeight.Bold, color = ink)
                        Text(a.desc, style = MaterialTheme.typography.bodySmall, color = ink)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
fun AccountTab(
    account: String?, status: String, onSignIn: () -> Unit, onSync: () -> Unit, onSignOut: () -> Unit,
    onExport: () -> Unit, onImport: () -> Unit
) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Tu cuenta", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = ink)
        GradCard(listOf(Color(0xFF8E7CFF), Color(0xFFFF8FB1)), Modifier.fillMaxWidth(), 28.dp) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (account == null) "☁️ Guarda tu progreso" else "☁️ Cuenta conectada",
                    fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    if (account == null) "Inicia sesión con Google para guardar tareas, racha y logros, y recuperarlos en otro teléfono."
                    else account,
                    color = Color.White
                )
                if (account == null) {
                    Button(onClick = onSignIn, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF6C5CE7))) {
                        Text("Iniciar sesión con Google")
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onSync, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF6C5CE7))) {
                            Text("Sincronizar")
                        }
                        OutlinedButton(onClick = onSignOut, colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                            Text("Salir")
                        }
                    }
                }
            }
        }
        GradCard(listOf(Color(0xFFFFF1C9), Color(0xFFFFD1E8)), Modifier.fillMaxWidth(), 28.dp) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("💾 Copia de seguridad manual", fontWeight = FontWeight.Bold, color = ink)
                Text("Exporta un código con todo tu progreso y guárdalo en tus notas. Impórtalo cuando lo necesites.",
                    style = MaterialTheme.typography.bodySmall, color = ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onExport) { Text("Exportar") }
                    OutlinedButton(onClick = onImport) { Text("Importar") }
                }
            }
        }
        if (status.isNotEmpty()) GradCard(listOf(Color.White, Color(0xFFFFEAF3)), Modifier.fillMaxWidth(), 20.dp) {
            Text(status, Modifier.padding(14.dp), style = MaterialTheme.typography.bodyMedium, color = ink)
        }
    }
}

@Composable
fun ImportDialog(onDismiss: () -> Unit, onImport: (String) -> Unit) {
    val c = LocalContext.current
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Importar copia") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pega el código. Se unirá con tus tareas actuales.")
                OutlinedTextField(text, { text = it }, label = { Text("Código CORETASK1:…") }, maxLines = 4)
                OutlinedButton(onClick = {
                    val clip = c.getSystemService(ClipboardManager::class.java).primaryClip
                    if (clip != null && clip.itemCount > 0) text = clip.getItemAt(0).text?.toString() ?: ""
                }) { Text("Pegar del portapapeles") }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onImport(text) }) { Text("Importar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (Task) -> Unit) {
    val c = LocalContext.current
    var title by remember { mutableStateOf("") }
    var due by remember { mutableLongStateOf(0L) }
    var pr by remember { mutableIntStateOf(1) }
    var rep by remember { mutableIntStateOf(0) }
    var early by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva tarea") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("¿Qué tienes que hacer?") }, singleLine = true)
                OutlinedButton(onClick = { pick(c) { due = it } }) {
                    Text(if (due == 0L) "Elegir fecha y hora" else fmt(due))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    priorities.forEachIndexed { i, n -> FilterChip(pr == i, { pr = i }, { Text(n) }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeats.forEachIndexed { i, n -> FilterChip(rep == i, { rep = i }, { Text(n) }, enabled = due != 0L) }
                }
                FilterChip(early, { early = !early }, { Text("Avisar 10 min antes") }, enabled = due != 0L)
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                onSave(Task(System.currentTimeMillis(), title.trim(), due, pr, if (due == 0L) 0 else rep,
                    if (early && due != 0L) 10 else 0, false))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
