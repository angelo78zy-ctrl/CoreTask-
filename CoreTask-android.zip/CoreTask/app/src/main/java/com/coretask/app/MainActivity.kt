package com.coretask.app

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#0A1420")
        window.navigationBarColor = android.graphics.Color.parseColor("#152030")
        setContent { App() }
    }
}

private val repeats = listOf("Una vez", "Diaria", "Semanal")
private val priorities = listOf("Baja", "Media", "Alta")
private fun fmt(ms: Long) = SimpleDateFormat("EEE d MMM, HH:mm", Locale("es")).format(Date(ms))
private fun chipDate(ms: Long) = SimpleDateFormat("d MMM HH:mm", Locale("es")).format(Date(ms))
private fun plural(n: Int, s: String) = "$n $s" + if (n == 1) "" else "s"

private fun askExactAlarm(c: Context) {
    val p = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    if (p.getBoolean("askedExact", false)) return
    p.edit().putBoolean("askedExact", true).apply()
    if (Build.VERSION.SDK_INT >= 31 && !c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms())
        c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + c.packageName)))
}

private fun pick(c: Context, onDone: (Long) -> Unit) {
    val cal = Calendar.getInstance()
    DatePickerDialog(c, { _, y, m, d ->
        TimePickerDialog(c, { _, h, min ->
            cal.set(y, m, d, h, min, 0); cal.set(Calendar.MILLISECOND, 0)
            onDone(cal.timeInMillis)
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
}

@Composable
fun App() {
    val c = LocalContext.current
    val prefs = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    var tasks by remember { mutableStateOf(Store.load(c)) }
    var log by remember { mutableStateOf(Store.log(c).map { it.first }) }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Task?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var celebrateAt by remember { mutableLongStateOf(0L) }
    var tab by remember { mutableIntStateOf(0) }
    var account by remember { mutableStateOf(Cloud.label()) }
    var status by remember { mutableStateOf("") }
    var importing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var seen by remember { mutableStateOf<Set<String>>(prefs.getStringSet("seen", emptySet()) ?: emptySet()) }

    fun refresh() {
        tasks = Store.load(c)
        log = Store.log(c).map { it.first }
        now = System.currentTimeMillis()
        seen = prefs.getStringSet("seen", emptySet()) ?: emptySet()
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { askExactAlarm(c) }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else askExactAlarm(c)
    }
    LaunchedEffect(Unit) { Store.load(c).forEach { Reminders.schedule(c, it) } }
    LaunchedEffect(Unit) {
        if (Cloud.user() != null) Cloud.pull(c) { status = it; refresh() }
        while (true) { delay(2000); refresh(); Cloud.autoPush(c) }
    }

    val toggle = { t: Task ->
        if (!t.done) {
            Reminders.finish(c, t.id)
            celebrateAt = System.currentTimeMillis()
        } else {
            Store.removeLog(c, t.id)
            Store.update(c, t.id) { it.copy(done = false) }?.let { Reminders.schedule(c, it) }
        }
        refresh()
    }
    val delete = { t: Task ->
        Reminders.cancel(c, t.id)
        Store.save(c, Store.load(c).filter { it.id != t.id })
        Store.markDeleted(c, t.id)
        refresh()
    }

    val signIn: () -> Unit = {
        scope.launch {
            status = "Conectando…"
            val err = Cloud.signIn(c)
            if (err == null) {
                account = Cloud.label()
                Cloud.pull(c) { status = it; refresh() }
            } else status = err
        }
    }
    val signOut: () -> Unit = {
        scope.launch { Cloud.signOut(c); account = null; status = "Sesión cerrada" }
    }
    val sync: () -> Unit = {
        status = "Sincronizando…"
        Cloud.pull(c) { status = it; refresh() }
    }
    val export: () -> Unit = {
        val code = Backup.code(c)
        c.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("CoreTask", code))
        status = "Código copiado al portapapeles ✅"
        c.startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code), "Guardar copia de seguridad"))
    }

    val stats = remember(log, now) { Stats(log, now) }
    val late = tasks.filter { !it.done && it.due in 1 until now }.sortedBy { it.due }
    val open = tasks.filter { !it.done && !(it.due in 1 until now) }
        .sortedWith(compareBy({ it.due == 0L }, { it.due }, { -it.priority }))
    val done = tasks.filter { it.done }
    val endOfToday = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
    }.timeInMillis
    val hoyTotal = stats.todayCount + tasks.count { !it.done && it.due in 1..endOfToday }

    val celebrating = now - celebrateAt < 5000
    val mood = when {
        late.isNotEmpty() && !celebrating -> 2
        celebrating || stats.todayCount > 0 -> 1
        else -> 0
    }
    val msg = when {
        celebrating -> "¡Bien hecho! +10 XP 🎉"
        late.isNotEmpty() -> "Tienes ${plural(late.size, "tarea")} atrasada${if (late.size == 1) "" else "s"}… ¡tú puedes!"
        tasks.isEmpty() -> "¡Hola! Soy Coco. Agrega tu primera tarea 💙"
        stats.streak >= 2 -> "¡Llevas ${stats.streak} días de racha! 🔥"
        open.isNotEmpty() -> "Hoy puedes con ${plural(open.size, "tarea")} 💪"
        else -> "¡Todo listo! Hora de descansar 😴"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Pal.accent, onPrimary = Pal.bg, background = Pal.bg, onBackground = Pal.text,
        surface = Pal.surface, onSurface = Pal.text, surfaceVariant = Pal.surface2, onSurfaceVariant = Pal.muted,
        outline = Pal.border, error = Pal.red, secondaryContainer = Pal.accentBg, onSecondaryContainer = Pal.accent
    )) {
        Scaffold(
            containerColor = Pal.bg,
            topBar = { TopBar(stats.streak, tab == 3) { tab = 3 } },
            bottomBar = { BottomNav(tab) { tab = it } },
            floatingActionButton = {
                if (tab == 0) Chunky(Modifier.size(68.dp), Pal.accent, Pal.accentDark, 22.dp, fill = true, onClick = { adding = true }) {
                    Text("+", color = Pal.bg, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> TasksTab(late, open, done, stats, hoyTotal, mood, msg, toggle, { editing = it }, delete)
                    1 -> AchTab(stats)
                    2 -> StatsTab(stats)
                    else -> AccountTab(account, status, signIn, sync, signOut, export) { importing = true }
                }
            }
        }
        if (adding || editing != null) AddDialog(editing, onDismiss = { adding = false; editing = null }) { t ->
            if (editing != null) Store.update(c, t.id) { t }?.let { Reminders.schedule(c, it) }
            else {
                Store.save(c, Store.load(c) + t)
                Reminders.schedule(c, t)
            }
            refresh()
            adding = false
            editing = null
        }
        if (importing) ImportDialog(onDismiss = { importing = false }) { text ->
            val ok = Backup.restore(c, text)
            status = if (ok) "Copia importada ✅" else "Código no válido"
            importing = false
            refresh()
        }
        val pending = stats.achievements.filter { it.ok && it.name !in seen }
        if (pending.isNotEmpty()) AlertDialog(
            onDismissRequest = {},
            containerColor = Pal.surface,
            title = { Text("¡Logro desbloqueado! 🎉", color = Pal.text) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    pending.forEach {
                        Text("${it.emoji} ${it.name}", fontWeight = FontWeight.Bold, color = Pal.accent)
                        Text(it.desc, color = Pal.muted)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    seen = seen + pending.map { it.name }
                    prefs.edit().putStringSet("seen", seen).apply()
                }) { Text("¡Genial!") }
            }
        )
    }
}

@Composable
fun TopBar(streak: Int, settingsActive: Boolean, onSettings: () -> Unit) {
    Column(Modifier.background(Pal.bg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Chunky(Modifier.size(46.dp), Pal.accent, Pal.accentDark, 14.dp, fill = true) {
                Text("✓", color = Pal.bg, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Text("core", color = Pal.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("task", color = Pal.accent, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.clip(RoundedCornerShape(50)).border(2.dp, Pal.accent, RoundedCornerShape(50))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🔥", fontSize = 16.sp)
                Spacer(Modifier.width(6.dp))
                Text(if (streak > 0) "Racha $streak" else "Racha", color = Pal.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            val shape = RoundedCornerShape(14.dp)
            Box(
                Modifier.size(46.dp).clip(shape).background(Pal.surface2)
                    .border(2.dp, if (settingsActive) Pal.accent else Pal.border, shape).clickable(onClick = onSettings),
                contentAlignment = Alignment.Center
            ) { Text("⚙️", fontSize = 20.sp) }
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(Pal.border))
    }
}

@Composable
fun BottomNav(tab: Int, onTab: (Int) -> Unit) {
    Column(Modifier.background(Pal.surface)) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(Pal.border))
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("✅" to "Tareas", "🏆" to "Logros", "📊" to "Stats").forEachIndexed { i, (e, n) ->
                val sel = tab == i
                val shape = RoundedCornerShape(20.dp)
                Column(
                    Modifier.weight(1f).clip(shape).border(2.dp, if (sel) Pal.accent else Color.Transparent, shape)
                        .clickable { onTab(i) }.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(e, fontSize = 24.sp)
                    Text(n.uppercase(), color = if (sel) Pal.accent else Pal.muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                }
            }
        }
    }
}

@Composable
fun TasksTab(
    late: List<Task>, open: List<Task>, done: List<Task>, s: Stats, hoyTotal: Int, mood: Int, msg: String,
    onToggle: (Task) -> Unit, onEdit: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    LazyColumn(
        Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 14.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { StatsCard(s, hoyTotal) }
        item { CocoCard(mood, s.level, msg) }
        section("Atrasadas", Pal.red, late, true, onToggle, onEdit, onDelete)
        section("Pendientes", Pal.accent, open, false, onToggle, onEdit, onDelete)
        section("Hechas", Pal.green, done, false, onToggle, onEdit, onDelete)
    }
}

@Composable
fun StatsCard(s: Stats, hoyTotal: Int) {
    Panel(Modifier.fillMaxWidth(), radius = 28.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Chunky(Modifier.size(64.dp), Pal.blue, Pal.blueDark, 18.dp, fill = true) {
                    Text("${s.level}", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("NIVEL", color = Pal.muted, fontSize = 13.sp, letterSpacing = 1.sp)
                    Text("Nivel ${s.level}", color = Pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.weight(1f))
                Panel(radius = 20.dp, borderColor = Pal.accent) {
                    Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🔥", fontSize = 26.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("RACHA", color = Pal.muted, fontSize = 12.sp, letterSpacing = 1.sp)
                            Text(plural(s.streak, "día"), color = Pal.accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth()) {
                Text("XP DEL NIVEL", color = Pal.muted, fontSize = 13.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                Text("${s.xpInLevel}/100", color = Pal.text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            val p by animateFloatAsState(s.xpInLevel / 100f, label = "xp")
            Box(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(50)).background(Pal.surface2)) {
                if (p > 0.01f) Box(
                    Modifier.fillMaxWidth(p).fillMaxHeight().clip(RoundedCornerShape(50))
                        .background(Brush.horizontalGradient(listOf(Pal.accent, Pal.blue)))
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Mini("⭐", "${s.xp}", "XP total", Modifier.weight(1f))
                Mini("⚡", "${s.todayCount}/$hoyTotal", "Hoy", Modifier.weight(1f))
                Mini("🔥", "${s.streak}", "Días", Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun CocoCard(mood: Int, level: Int, msg: String) {
    Panel(Modifier.fillMaxWidth(), radius = 28.dp) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Mascot(mood, level, Modifier.size(112.dp))
            Column(Modifier.weight(1f).padding(end = 10.dp)) {
                Text("COCO", color = Pal.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Text(msg, color = Pal.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

private fun LazyListScope.section(
    title: String, color: Color, list: List<Task>, late: Boolean,
    onToggle: (Task) -> Unit, onEdit: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    if (list.isEmpty()) return
    item { SectionHeader(title.uppercase(), color, list.size) }
    items(list, key = { it.id }) { t -> TaskRow(t, late, { onToggle(t) }, { onEdit(t) }, { onDelete(t) }) }
}

@Composable
fun RoundBtn(emoji: String, bg: Color, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).background(bg).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(emoji, fontSize = 17.sp)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskRow(t: Task, late: Boolean, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val cat = t.category.coerceIn(0, categories.lastIndex)
    val accent = if (t.done) Pal.green else categoryColors[cat]
    val (pfg, pbg) = prioColors(t.priority)
    Panel(Modifier.fillMaxWidth(), radius = 28.dp, fill = if (t.done) Pal.surface2 else Pal.surface) {
        Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(8.dp).fillMaxHeight().background(if (late) Pal.red else accent))
            Box(
                Modifier.padding(start = 12.dp).size(40.dp).clip(CircleShape).border(3.dp, accent, CircleShape)
                    .background(if (t.done) accent else Color.Transparent).clickable(onClick = onToggle),
                contentAlignment = Alignment.Center
            ) {
                if (t.done) Text("✓", color = Pal.bg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t.title, color = if (t.done) Pal.muted else Pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Chip(categories[cat], categoryColors[cat], categoryBg[cat])
                    if (t.due > 0) Chip(chipDate(t.due), if (late) Pal.red else Pal.muted, if (late) Pal.redBg else Pal.surface2, "📅")
                    Chip(priorities[t.priority.coerceIn(0, 2)], pfg, pbg)
                    if (t.repeat > 0) Chip(repeats[t.repeat.coerceIn(0, 2)], Pal.purple, Pal.purpleBg, "🔁")
                }
            }
            Column(Modifier.padding(end = 10.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("+10 XP", Pal.blueText, Pal.blueBg)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RoundBtn("✏️", Pal.surface2, onEdit)
                    RoundBtn("🗑️", Pal.redBg, onDelete)
                }
            }
        }
    }
}

@Composable
fun Segment(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) Pal.accent else Pal.surface2)
            .clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 9.dp)
    ) {
        Text(label, color = if (selected) Pal.bg else Pal.muted, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}

@Composable
fun StatsTab(s: Stats) {
    var month by remember { mutableStateOf(false) }
    val vals = if (month) s.month4 else s.week
    val labels = if (month) listOf("−3 sem", "−2 sem", "−1 sem", "Esta") else s.weekLabels
    val total = if (month) s.monthTotal else s.weekTotal
    val prev = if (month) s.prevMonth else s.prevWeek
    val top = maxOf(1, vals.max())
    val d = total - prev
    val unit = if (month) "el mes" else "la semana"
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("ESTADÍSTICAS", color = Pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Segment("SEMANA", !month) { month = false }
            Segment("MES", month) { month = true }
        }
        Panel(Modifier.fillMaxWidth(), radius = 28.dp) {
            Column(Modifier.padding(18.dp)) {
                Text("$total", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Pal.accent)
                Text(if (month) "TAREAS COMPLETADAS ESTE MES" else "TAREAS COMPLETADAS EN 7 DÍAS",
                    color = Pal.muted, fontSize = 12.sp, letterSpacing = 1.sp)
                Text(
                    when {
                        d > 0 -> "▲ $d más que $unit anterior 🎉"
                        d < 0 -> "▼ ${-d} menos que $unit anterior. ¡Tú puedes!"
                        else -> "Igual que $unit anterior"
                    },
                    color = if (d > 0) Pal.green else Pal.muted, fontSize = 13.sp
                )
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth().height(170.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceEvenly) {
                    vals.forEachIndexed { i, v ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$v", color = Pal.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Box(Modifier.width(26.dp).height((110.dp * v / top).coerceAtLeast(5.dp)).background(
                                Brush.verticalGradient(listOf(Pal.accent, Pal.blue)), RoundedCornerShape(10.dp)))
                            Text(labels[i].uppercase(), color = Pal.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(if (month) "ÚLTIMAS 4 SEMANAS" else "ÚLTIMOS 7 DÍAS", color = Pal.muted, fontSize = 11.sp, letterSpacing = 1.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Mini("🔥", "${s.streak}", "Racha", Modifier.weight(1f))
            Mini("🏅", "${s.bestStreak}", "Mejor racha", Modifier.weight(1f))
            Mini("📅", "${s.activeDays}/7", "Días activos", Modifier.weight(1f))
        }
        Mini("⭐", "${s.total}", "Tareas completadas en total", Modifier.fillMaxWidth())
    }
}

@Composable
fun AchTab(s: Stats) {
    val got = s.achievements.count { it.ok }
    LazyColumn(Modifier.padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("LOGROS", color = Pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("$got de ${s.achievements.size} desbloqueados", color = Pal.muted)
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(50)).background(Pal.surface2)) {
                if (got > 0) Box(
                    Modifier.fillMaxWidth(got / s.achievements.size.toFloat()).fillMaxHeight().clip(RoundedCornerShape(50))
                        .background(Brush.horizontalGradient(listOf(Pal.accent, Pal.blue)))
                )
            }
        }
        items(s.achievements) { a ->
            Panel(Modifier.fillMaxWidth().alpha(if (a.ok) 1f else .55f), radius = 24.dp, borderColor = if (a.ok) Pal.accent else Pal.border) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(if (a.ok) Pal.accentBg else Pal.surface2),
                        contentAlignment = Alignment.Center) {
                        Text(if (a.ok) a.emoji else "🔒", fontSize = 26.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(a.name, color = Pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text(a.desc, color = Pal.muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AccountTab(
    account: String?, status: String, onSignIn: () -> Unit, onSync: () -> Unit, onSignOut: () -> Unit,
    onExport: () -> Unit, onImport: () -> Unit
) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("CUENTA", color = Pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Panel(Modifier.fillMaxWidth(), radius = 28.dp) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (account == null) "☁️ Guarda tu progreso" else "☁️ Cuenta conectada",
                    color = Pal.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (account == null) "Inicia sesión con Google para guardar tareas, racha y logros, y recuperarlos en otro teléfono."
                    else account,
                    color = Pal.muted
                )
                if (account == null) {
                    Chunky(Modifier.fillMaxWidth(), Pal.accent, Pal.accentDark, onClick = onSignIn) {
                        Text("Iniciar sesión con Google", color = Pal.bg, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Chunky(Modifier.weight(1f), Pal.accent, Pal.accentDark, onClick = onSync) {
                            Text("Sincronizar", color = Pal.bg, fontWeight = FontWeight.Bold)
                        }
                        Chunky(Modifier.weight(1f), Pal.surface2, Pal.border, onClick = onSignOut) {
                            Text("Salir", color = Pal.text, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        Panel(Modifier.fillMaxWidth(), radius = 28.dp) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("💾 Copia de seguridad manual", color = Pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Exporta un código con todo tu progreso y guárdalo en tus notas. Impórtalo cuando lo necesites.",
                    color = Pal.muted, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chunky(Modifier.weight(1f), Pal.blue, Pal.blueDark, onClick = onExport) {
                        Text("Exportar", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Chunky(Modifier.weight(1f), Pal.surface2, Pal.border, onClick = onImport) {
                        Text("Importar", color = Pal.text, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        NotifPanel()
        if (status.isNotEmpty()) Panel(Modifier.fillMaxWidth(), radius = 20.dp, borderColor = Pal.accent) {
            Text(status, Modifier.padding(14.dp), color = Pal.text)
        }
    }
}

@Composable
fun ImportDialog(onDismiss: () -> Unit, onImport: (String) -> Unit) {
    val c = LocalContext.current
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.surface,
        title = { Text("Importar copia", color = Pal.text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pega el código. Se unirá con tus tareas actuales.", color = Pal.muted)
                OutlinedTextField(text, { text = it }, label = { Text("Código CORETASK1:…") }, maxLines = 4)
                OutlinedButton(onClick = {
                    val clip = c.getSystemService(ClipboardManager::class.java).primaryClip
                    if (clip != null && clip.itemCount > 0) text = clip.getItemAt(0).text?.toString() ?: ""
                }) { Text("Pegar del portapapeles") }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onImport(text) }) { Text("Importar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDialog(initial: Task?, onDismiss: () -> Unit, onSave: (Task) -> Unit) {
    val c = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var due by remember { mutableLongStateOf(initial?.due ?: 0L) }
    var pr by remember { mutableIntStateOf(initial?.priority ?: 1) }
    var rep by remember { mutableIntStateOf(initial?.repeat ?: 0) }
    var early by remember { mutableStateOf((initial?.lead ?: 0) > 0) }
    var cat by remember { mutableIntStateOf(initial?.category ?: 0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Pal.surface,
        title = { Text(if (initial == null) "Nueva tarea" else "Editar tarea", color = Pal.text) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("¿Qué tienes que hacer?") }, singleLine = true)
                OutlinedButton(onClick = { pick(c) { due = it } }) {
                    Text(if (due == 0L) "Elegir fecha y hora" else fmt(due))
                }
                Text("CATEGORÍA", color = Pal.muted, fontSize = 12.sp, letterSpacing = 1.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.forEachIndexed { i, n -> FilterChip(cat == i, { cat = i }, { Text(n) }) }
                }
                Text("PRIORIDAD", color = Pal.muted, fontSize = 12.sp, letterSpacing = 1.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    priorities.forEachIndexed { i, n -> FilterChip(pr == i, { pr = i }, { Text(n) }) }
                }
                Text("REPETIR", color = Pal.muted, fontSize = 12.sp, letterSpacing = 1.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeats.forEachIndexed { i, n -> FilterChip(rep == i, { rep = i }, { Text(n) }, enabled = due != 0L) }
                }
                FilterChip(early, { early = !early }, { Text("Avisar 10 min antes") }, enabled = due != 0L)
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                onSave(Task(initial?.id ?: System.currentTimeMillis(), title.trim(), due, pr, if (due == 0L) 0 else rep,
                    if (early && due != 0L) 10 else 0, initial?.done ?: false, cat))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
