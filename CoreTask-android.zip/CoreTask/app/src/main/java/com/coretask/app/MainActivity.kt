package com.coretask.app

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val priorities = listOf("Baja", "Media", "Alta")
private val repeats = listOf("Una vez", "Diaria", "Semanal")
private fun fmt(ms: Long) = SimpleDateFormat("EEE d MMM, HH:mm", Locale("es")).format(Date(ms))

private fun askExactAlarm(c: Context) {
    val p = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    if (p.getBoolean("askedExact", false)) return
    p.edit().putBoolean("askedExact", true).apply()
    if (Build.VERSION.SDK_INT >= 31 && !c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms())
        c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + c.packageName)))
}

private fun pick(c: Context, onDone: (Long) -> Unit) {
    val cal = Calendar.getInstance()
    DatePickerDialog(c, { _, y, m, d ->
        TimePickerDialog(c, { _, h, min ->
            cal.set(y, m, d, h, min, 0); cal.set(Calendar.MILLISECOND, 0)
            onDone(cal.timeInMillis)
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
}

@Composable
fun App() {
    val c = LocalContext.current
    var tasks by remember { mutableStateOf(Store.load(c)) }
    var adding by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { askExactAlarm(c) }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else askExactAlarm(c)
    }
    LaunchedEffect(Unit) {
        while (true) { delay(5000); tasks = Store.load(c); now = System.currentTimeMillis() }
    }

    val toggle = { t: Task ->
        if (!t.done) Reminders.finish(c, t.id)
        else Store.update(c, t.id) { it.copy(done = false) }?.let { Reminders.schedule(c, it) }
        tasks = Store.load(c)
    }
    val delete = { t: Task ->
        Reminders.cancel(c, t.id)
        Store.save(c, Store.load(c).filter { it.id != t.id })
        tasks = Store.load(c)
    }

    val late = tasks.filter { !it.done && it.due in 1 until now }.sortedBy { it.due }
    val open = tasks.filter { !it.done && !(it.due in 1 until now) }.sortedWith(compareBy({ it.due == 0L }, { it.due }, { -it.priority }))
    val done = tasks.filter { it.done }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF3355E8))) {
        Scaffold(floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { adding = true }) { Text("Nueva tarea") }
        }) { pad ->
            LazyColumn(
                Modifier.padding(pad).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    Spacer(Modifier.height(16.dp))
                    Text("CoreTask", style = MaterialTheme.typography.headlineMedium)
                    Text(if (tasks.isEmpty()) "Sin tareas todavía" else "${done.size} de ${tasks.size} hechas")
                    LinearProgressIndicator(
                        progress = { if (tasks.isEmpty()) 0f else done.size.toFloat() / tasks.size },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                    )
                }
                section("Caducadas", late, true, toggle, delete)
                section("Pendientes", open, false, toggle, delete)
                section("Hechas", done, false, toggle, delete)
                item { Spacer(Modifier.height(88.dp)) }
            }
        }
        if (adding) AddDialog(onDismiss = { adding = false }) { t ->
            Store.save(c, Store.load(c) + t)
            Reminders.schedule(c, t)
            tasks = Store.load(c)
            adding = false
        }
    }
}

private fun LazyListScope.section(
    title: String, list: List<Task>, late: Boolean, onToggle: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    if (list.isEmpty()) return
    item {
        Text(title, style = MaterialTheme.typography.titleMedium,
            color = if (late) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(top = 8.dp))
    }
    items(list, key = { it.id }) { t -> TaskRow(t, late, { onToggle(t) }, { onDelete(t) }) }
}

@Composable
fun TaskRow(t: Task, late: Boolean, onToggle: () -> Unit, onDelete: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(t.done, { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(t.title, style = MaterialTheme.typography.bodyLarge,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null)
                val meta = listOfNotNull(
                    if (t.due > 0) fmt(t.due) else null,
                    if (t.priority == 2) "Prioridad alta" else null,
                    if (t.repeat > 0) repeats[t.repeat].lowercase() else null
                ).joinToString(" · ")
                if (meta.isNotEmpty()) Text((if (late) "Caducada: " else "") + meta,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (late) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onDelete) { Text("Borrar") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (Task) -> Unit) {
    val c = LocalContext.current
    var title by remember { mutableStateOf("") }
    var due by remember { mutableLongStateOf(0L) }
    var pr by remember { mutableIntStateOf(1) }
    var rep by remember { mutableIntStateOf(0) }
    var early by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva tarea") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("¿Qué tienes que hacer?") }, singleLine = true)
                OutlinedButton(onClick = { pick(c) { due = it } }) {
                    Text(if (due == 0L) "Elegir fecha y hora" else fmt(due))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    priorities.forEachIndexed { i, n -> FilterChip(pr == i, { pr = i }, { Text(n) }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeats.forEachIndexed { i, n -> FilterChip(rep == i, { rep = i }, { Text(n) }, enabled = due != 0L) }
                }
                FilterChip(early, { early = !early }, { Text("Avisar 10 min antes") }, enabled = due != 0L)
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                onSave(Task(System.currentTimeMillis(), title.trim(), due, pr, if (due == 0L) 0 else rep, if (early && due != 0L) 10 else 0, false))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
