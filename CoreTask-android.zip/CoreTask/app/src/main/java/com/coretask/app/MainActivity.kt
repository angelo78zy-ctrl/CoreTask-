package com.coretask.app

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val repeats = listOf("Una vez", "Diaria", "Semanal")
private val priorities = listOf("Baja", "Media", "Alta")
private val cardColors @Composable get() = CardDefaults.cardColors(containerColor = Color.White)
private fun fmt(ms: Long) = SimpleDateFormat("EEE d MMM, HH:mm", Locale("es")).format(Date(ms))
private fun plural(n: Int, s: String) = "$n $s" + if (n == 1) "" else "s"

private fun askExactAlarm(c: Context) {
    val p = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    if (p.getBoolean("askedExact", false)) return
    p.edit().putBoolean("askedExact", true).apply()
    if (Build.VERSION.SDK_INT >= 31 && !c.getSystemService(AlarmManager::class.java).canScheduleExactAlarms())
        c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + c.packageName)))
}

private fun pick(c: Context, onDone: (Long) -> Unit) {
    val cal = Calendar.getInstance()
    DatePickerDialog(c, { _, y, m, d ->
        TimePickerDialog(c, { _, h, min ->
            cal.set(y, m, d, h, min, 0); cal.set(Calendar.MILLISECOND, 0)
            onDone(cal.timeInMillis)
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
}

@Composable
fun App() {
    val c = LocalContext.current
    val prefs = c.getSharedPreferences("coretask", Context.MODE_PRIVATE)
    var tasks by remember { mutableStateOf(Store.load(c)) }
    var log by remember { mutableStateOf(Store.log(c).map { it.first }) }
    var adding by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var celebrateAt by remember { mutableLongStateOf(0L) }
    var tab by remember { mutableIntStateOf(0) }
    var seen by remember { mutableStateOf<Set<String>>(prefs.getStringSet("seen", emptySet()) ?: emptySet()) }

    fun refresh() {
        tasks = Store.load(c)
        log = Store.log(c).map { it.first }
        now = System.currentTimeMillis()
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { askExactAlarm(c) }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS) else askExactAlarm(c)
    }
    LaunchedEffect(Unit) { while (true) { delay(2000); refresh() } }

    val toggle = { t: Task ->
        if (!t.done) {
            Reminders.finish(c, t.id)
            celebrateAt = System.currentTimeMillis()
        } else {
            Store.removeLog(c, t.id)
            Store.update(c, t.id) { it.copy(done = false) }?.let { Reminders.schedule(c, it) }
        }
        refresh()
    }
    val delete = { t: Task ->
        Reminders.cancel(c, t.id)
        Store.save(c, Store.load(c).filter { it.id != t.id })
        refresh()
    }

    val stats = remember(log, now) { Stats(log, now) }
    val late = tasks.filter { !it.done && it.due in 1 until now }.sortedBy { it.due }
    val open = tasks.filter { !it.done && !(it.due in 1 until now) }
        .sortedWith(compareBy({ it.due == 0L }, { it.due }, { -it.priority }))
    val done = tasks.filter { it.done }

    val celebrating = now - celebrateAt < 5000
    val mood = when {
        late.isNotEmpty() && !celebrating -> 2
        celebrating || stats.todayCount > 0 -> 1
        else -> 0
    }
    val msg = when {
        celebrating -> "¡Bien hecho! +10 XP 🎉"
        late.isNotEmpty() -> "Tienes ${plural(late.size, "tarea")} caducada${if (late.size == 1) "" else "s"}… ¡tú puedes! 🥺"
        tasks.isEmpty() -> "¡Hola! Soy Coco 💜 Agrega tu primera tarea."
        stats.streak >= 2 -> "¡Llevas ${stats.streak} días de racha! 🔥"
        open.isNotEmpty() -> "Hoy puedes con ${plural(open.size, "tarea")} 💪"
        else -> "¡Todo listo! Hora de descansar 😴"
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF6C5CE7), secondary = Color(0xFFFF8FB1))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFEDE9FF), Color(0xFFFFF1F6))))) {
            Scaffold(
                containerColor = Color.Transparent,
                bottomBar = {
                    NavigationBar(containerColor = Color.White.copy(alpha = .92f)) {
                        listOf("🏠" to "Tareas", "📈" to "Progreso", "🏅" to "Logros").forEachIndexed { i, (e, n) ->
                            NavigationBarItem(tab == i, { tab = i }, { Text(e, fontSize = 22.sp) }, label = { Text(n) })
                        }
                    }
                },
                floatingActionButton = {
                    if (tab == 0) ExtendedFloatingActionButton(
                        onClick = { adding = true },
                        containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White
                    ) { Text("✨ Nueva tarea") }
                }
            ) { pad ->
                Box(Modifier.padding(pad)) {
                    when (tab) {
                        0 -> TasksTab(late, open, done, stats, mood, msg, toggle, delete)
                        1 -> ProgressTab(stats)
                        else -> AchTab(stats)
                    }
                }
            }
        }
        if (adding) AddDialog(onDismiss = { adding = false }) { t ->
            Store.save(c, Store.load(c) + t)
            Reminders.schedule(c, t)
            refresh()
            adding = false
        }
        val pending = stats.achievements.filter { it.ok && it.name !in seen }
        if (pending.isNotEmpty()) AlertDialog(
            onDismissRequest = {},
            title = { Text("¡Logro desbloqueado! 🎉") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    pending.forEach { Text("${it.emoji} ${it.name}", fontWeight = FontWeight.Bold); Text(it.desc) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    seen = seen + pending.map { it.name }
                    prefs.edit().putStringSet("seen", seen).apply()
                }) { Text("¡Genial!") }
            }
        )
    }
}

@Composable
fun TasksTab(
    late: List<Task>, open: List<Task>, done: List<Task>, s: Stats, mood: Int, msg: String,
    onToggle: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Mascot(mood, s.level, Modifier.size(132.dp))
                Column(Modifier.weight(1f)) {
                    Card(shape = RoundedCornerShape(18.dp), colors = cardColors) {
                        Text(msg, Modifier.padding(12.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Nivel ${s.level} · ${s.xpInLevel}/50 XP", fontWeight = FontWeight.SemiBold)
                    val p by animateFloatAsState(s.xpInLevel / 50f, label = "xp")
                    LinearProgressIndicator(
                        progress = { p },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp))
                    )
                    Text("🔥 Racha: ${plural(s.streak, "día")}")
                }
            }
        }
        section("⚠️ Caducadas", list = late, late = true, onToggle = onToggle, onDelete = onDelete)
        section("📝 Pendientes", list = open, late = false, onToggle = onToggle, onDelete = onDelete)
        section("✅ Hechas", list = done, late = false, onToggle = onToggle, onDelete = onDelete)
        item { Spacer(Modifier.height(88.dp)) }
    }
}

private fun LazyListScope.section(
    title: String, list: List<Task>, late: Boolean, onToggle: (Task) -> Unit, onDelete: (Task) -> Unit
) {
    if (list.isEmpty()) return
    item {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            color = if (late) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(top = 8.dp))
    }
    items(list, key = { it.id }) { t -> TaskRow(t, late, { onToggle(t) }, { onDelete(t) }) }
}

@Composable
fun TaskRow(t: Task, late: Boolean, onToggle: () -> Unit, onDelete: () -> Unit) {
    val strip = when (t.priority) { 2 -> Color(0xFFFF6B8A); 1 -> Color(0xFFFFB84D); else -> Color(0xFF4CD39B) }
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (late) Color(0xFFFFEEF1) else Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(6.dp).fillMaxHeight().background(strip))
            Checkbox(t.done, { onToggle() }, modifier = Modifier.padding(start = 4.dp))
            Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
                Text(t.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium,
                    textDecoration = if (t.done) TextDecoration.LineThrough else null)
                val meta = listOfNotNull(
                    if (t.due > 0) "⏰ " + fmt(t.due) else null,
                    if (t.repeat > 0) "🔁 " + repeats[t.repeat].lowercase() else null,
                    if (t.lead > 0) "🔔 ${t.lead} min antes" else null
                ).joinToString("  ")
                if (meta.isNotEmpty()) Text((if (late) "⚠️ Caducada · " else "") + meta,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (late) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton(onClick = onDelete) { Text("🗑️") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressTab(s: Stats) {
    var month by remember { mutableStateOf(false) }
    val vals = if (month) s.month4 else s.week
    val labels = if (month) listOf("−3 sem", "−2 sem", "−1 sem", "Esta") else s.weekLabels
    val total = if (month) s.monthTotal else s.weekTotal
    val prev = if (month) s.prevMonth else s.prevWeek
    val top = maxOf(1, vals.max())
    val d = total - prev
    val unit = if (month) "el mes" else "la semana"
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Tu progreso", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(!month, { month = false }, { Text("Semana") })
            FilterChip(month, { month = true }, { Text("Mes") })
        }
        Card(shape = RoundedCornerShape(24.dp), colors = cardColors) {
            Column(Modifier.padding(16.dp)) {
                Text("$total", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(if (month) "tareas completadas este mes" else "tareas completadas en 7 días")
                Text(
                    when {
                        d > 0 -> "▲ $d más que $unit anterior 🎉"
                        d < 0 -> "▼ ${-d} menos que $unit anterior. ¡Tú puedes!"
                        else -> "Igual que $unit anterior"
                    },
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().height(170.dp), verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceEvenly) {
                    vals.forEachIndexed { i, v ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("$v", style = MaterialTheme.typography.labelMedium)
                            Box(Modifier.width(26.dp).height((110.dp * v / top).coerceAtLeast(5.dp)).background(
                                Brush.verticalGradient(listOf(Color(0xFFFF8FB1), Color(0xFF6C5CE7))), RoundedCornerShape(10.dp)))
                            Text(labels[i], style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Text(if (month) "Últimas 4 semanas" else "Últimos 7 días", style = MaterialTheme.typography.labelSmall)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Mini("🔥", "${s.streak}", "Racha", Modifier.weight(1f))
            Mini("🏅", "${s.bestStreak}", "Mejor racha", Modifier.weight(1f))
            Mini("📅", "${s.activeDays}/7", "Días activos", Modifier.weight(1f))
        }
        Mini("⭐", "${s.total}", "Tareas completadas en total", Modifier.fillMaxWidth())
    }
}

@Composable
fun Mini(emoji: String, value: String, label: String, modifier: Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = cardColors) {
        Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 22.sp)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
fun AchTab(s: Stats) {
    val got = s.achievements.count { it.ok }
    LazyColumn(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Spacer(Modifier.height(16.dp))
            Text("Logros", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("$got de ${s.achievements.size} desbloqueados")
            LinearProgressIndicator(
                progress = { got / s.achievements.size.toFloat() },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp).height(8.dp).clip(RoundedCornerShape(8.dp))
            )
        }
        items(s.achievements) { a ->
            Card(Modifier.fillMaxWidth().alpha(if (a.ok) 1f else .5f), shape = RoundedCornerShape(18.dp), colors = cardColors) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (a.ok) a.emoji else "🔒", fontSize = 30.sp)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        Text(a.desc, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDialog(onDismiss: () -> Unit, onSave: (Task) -> Unit) {
    val c = LocalContext.current
    var title by remember { mutableStateOf("") }
    var due by remember { mutableLongStateOf(0L) }
    var pr by remember { mutableIntStateOf(1) }
    var rep by remember { mutableIntStateOf(0) }
    var early by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nueva tarea") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("¿Qué tienes que hacer?") }, singleLine = true)
                OutlinedButton(onClick = { pick(c) { due = it } }) {
                    Text(if (due == 0L) "Elegir fecha y hora" else fmt(due))
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    priorities.forEachIndexed { i, n -> FilterChip(pr == i, { pr = i }, { Text(n) }) }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeats.forEachIndexed { i, n -> FilterChip(rep == i, { rep = i }, { Text(n) }, enabled = due != 0L) }
                }
                FilterChip(early, { early = !early }, { Text("Avisar 10 min antes") }, enabled = due != 0L)
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                onSave(Task(System.currentTimeMillis(), title.trim(), due, pr, if (due == 0L) 0 else rep,
                    if (early && due != 0L) 10 else 0, false))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
