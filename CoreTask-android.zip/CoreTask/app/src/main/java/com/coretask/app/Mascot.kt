package com.coretask.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate

// Coco, la mascota. mood: 0 tranquila, 1 feliz, 2 preocupada. Con el nivel gana moño (3) y corona (5).
@Composable
fun Mascot(mood: Int, level: Int, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "coco")
    val bounce by t.animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val blink by t.animateFloat(
        1f, 1f,
        infiniteRepeatable(keyframes<Float> { durationMillis = 3400; 1f at 0; 1f at 3200; 0.1f at 3300; 1f at 3400 }),
        label = "k"
    )
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val pink = Color(0xFFFF9FBD); val light = Color(0xFFFFD1DC); val ink = Color(0xFF3B2A4A)
        drawOval(Color(0x22000000), Offset(w * .2f, h * .92f), Size(w * .6f, h * .05f))
        translate(top = -bounce * (if (mood == 1) 16f else 7f)) {
            fun poly(col: Color, vararg p: Offset) =
                drawPath(Path().apply { moveTo(p[0].x, p[0].y); for (i in 1 until p.size) lineTo(p[i].x, p[i].y); close() }, col)
            // orejas
            poly(pink, Offset(w * .20f, h * .42f), Offset(w * .24f, h * .08f), Offset(w * .46f, h * .26f))
            poly(pink, Offset(w * .80f, h * .42f), Offset(w * .76f, h * .08f), Offset(w * .54f, h * .26f))
            poly(light, Offset(w * .26f, h * .36f), Offset(w * .27f, h * .17f), Offset(w * .40f, h * .27f))
            poly(light, Offset(w * .74f, h * .36f), Offset(w * .73f, h * .17f), Offset(w * .60f, h * .27f))
            // patitas y cuerpo
            drawOval(pink, Offset(w * .27f, h * .80f), Size(w * .17f, h * .12f))
            drawOval(pink, Offset(w * .56f, h * .80f), Size(w * .17f, h * .12f))
            drawCircle(
                brush = Brush.radialGradient(listOf(light, pink), center = Offset(w * .42f, h * .42f), radius = w * .5f),
                radius = w * .34f, center = Offset(w * .5f, h * .56f)
            )
            // ojos
            for (x in listOf(w * .36f, w * .64f)) {
                val y = h * .50f
                if (mood == 1) {
                    drawArc(ink, 200f, 140f, false, Offset(x - w * .05f, y - w * .03f), Size(w * .10f, w * .08f),
                        style = Stroke(w * .018f, cap = StrokeCap.Round))
                } else {
                    drawOval(ink, Offset(x - w * .0425f, y - w * .0575f * blink), Size(w * .085f, w * .115f * blink))
                    if (blink > .5f) drawCircle(Color.White, w * .014f, Offset(x + w * .012f, y - w * .022f))
                }
            }
            if (mood == 2) {
                drawLine(ink, Offset(w * .31f, h * .445f), Offset(w * .40f, h * .415f), w * .014f, StrokeCap.Round)
                drawLine(ink, Offset(w * .69f, h * .445f), Offset(w * .60f, h * .415f), w * .014f, StrokeCap.Round)
            }
            // mejillas y boca
            drawOval(Color(0x66FF4F86), Offset(w * .24f, h * .56f), Size(w * .11f, h * .06f))
            drawOval(Color(0x66FF4F86), Offset(w * .65f, h * .56f), Size(w * .11f, h * .06f))
            when (mood) {
                1 -> drawArc(Color(0xFFD6336C), 0f, 180f, true, Offset(w * .45f, h * .57f), Size(w * .10f, h * .08f))
                2 -> drawArc(ink, 200f, 140f, false, Offset(w * .46f, h * .62f), Size(w * .08f, h * .05f),
                    style = Stroke(w * .012f, cap = StrokeCap.Round))
                else -> drawArc(ink, 20f, 140f, false, Offset(w * .46f, h * .575f), Size(w * .08f, h * .05f),
                    style = Stroke(w * .012f, cap = StrokeCap.Round))
            }
            // accesorios por nivel
            if (level >= 3) {
                val bx = w * .30f; val by = h * .21f; val bow = Color(0xFF6C5CE7)
                poly(bow, Offset(bx, by), Offset(bx - w * .07f, by - w * .045f), Offset(bx - w * .07f, by + w * .045f))
                poly(bow, Offset(bx, by), Offset(bx + w * .07f, by - w * .045f), Offset(bx + w * .07f, by + w * .045f))
                drawCircle(bow, w * .022f, Offset(bx, by))
            }
            if (level >= 5) {
                poly(Color(0xFFFFC53D), Offset(w * .40f, h * .20f), Offset(w * .39f, h * .07f), Offset(w * .45f, h * .13f),
                    Offset(w * .50f, h * .05f), Offset(w * .55f, h * .13f), Offset(w * .61f, h * .07f), Offset(w * .60f, h * .20f))
            }
        }
    }
}
