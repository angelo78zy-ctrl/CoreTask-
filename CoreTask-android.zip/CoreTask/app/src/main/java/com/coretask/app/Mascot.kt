package com.coretask.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate

// Coco, la mascota. mood: 0 tranquila, 1 feliz, 2 preocupada. Con el nivel gana moño (3) y corona (5).
@Composable
fun Mascot(mood: Int, level: Int, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "coco")
    val bounce by t.animateFloat(0f, 1f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val blink by t.animateFloat(
        1f, 1f,
        infiniteRepeatable(keyframes<Float> { durationMillis = 3400; 1f at 0; 1f at 3200; 0.1f at 3300; 1f at 3400 }),
        label = "k"
    )
    Canvas(modifier) {
        val w = size.width; val h = size.height
        val body1 = Color(0xFF8BE9FF); val body2 = Color(0xFF2F9BFF); val edge = Color(0xFF1B66C9)
        val navy = Color(0xFF0F1F3D); val earIn = Color(0xFFBDEBFF)
        drawOval(Color(0x55000000), Offset(w * .2f, h * .92f), Size(w * .6f, h * .05f))
        translate(top = -bounce * (if (mood == 1) 16f else 7f)) {
            fun poly(col: Color, p: List<Offset>) =
                drawPath(Path().apply { moveTo(p[0].x, p[0].y); for (i in 1 until p.size) lineTo(p[i].x, p[i].y); close() }, col)
            fun star(cx: Float, cy: Float, r: Float, col: Color) = poly(col, listOf(
                Offset(cx, cy - r), Offset(cx + r * .28f, cy - r * .28f), Offset(cx + r, cy), Offset(cx + r * .28f, cy + r * .28f),
                Offset(cx, cy + r), Offset(cx - r * .28f, cy + r * .28f), Offset(cx - r, cy), Offset(cx - r * .28f, cy - r * .28f)))
            // orejas
            poly(body2, listOf(Offset(w * .20f, h * .42f), Offset(w * .24f, h * .08f), Offset(w * .46f, h * .26f)))
            poly(body2, listOf(Offset(w * .80f, h * .42f), Offset(w * .76f, h * .08f), Offset(w * .54f, h * .26f)))
            poly(earIn, listOf(Offset(w * .26f, h * .36f), Offset(w * .27f, h * .17f), Offset(w * .40f, h * .27f)))
            poly(earIn, listOf(Offset(w * .74f, h * .36f), Offset(w * .73f, h * .17f), Offset(w * .60f, h * .27f)))
            // patitas y cuerpo
            drawOval(body2, Offset(w * .27f, h * .80f), Size(w * .17f, h * .12f))
            drawOval(body2, Offset(w * .56f, h * .80f), Size(w * .17f, h * .12f))
            drawCircle(
                brush = Brush.radialGradient(listOf(body1, body2), center = Offset(w * .42f, h * .42f), radius = w * .5f),
                radius = w * .34f, center = Offset(w * .5f, h * .56f)
            )
            drawCircle(edge, w * .34f, Offset(w * .5f, h * .56f), style = Stroke(w * .016f))
            drawOval(Color(0xFFE3F9FF), Offset(w * .37f, h * .71f), Size(w * .26f, h * .15f))
            // ojos
            for (x in listOf(w * .37f, w * .63f)) {
                val y = h * .50f
                if (mood == 1) {
                    drawArc(navy, 200f, 140f, false, Offset(x - w * .055f, y - w * .03f), Size(w * .11f, w * .085f),
                        style = Stroke(w * .02f, cap = StrokeCap.Round))
                } else {
                    drawOval(navy, Offset(x - w * .05f, y - w * .065f * blink), Size(w * .10f, w * .13f * blink))
                    if (blink > .5f) {
                        drawCircle(Color.White, w * .02f, Offset(x + w * .014f, y - w * .03f))
                        drawCircle(Color.White, w * .009f, Offset(x - w * .016f, y + w * .02f))
                    }
                }
            }
            if (mood == 2) {
                drawLine(navy, Offset(w * .30f, h * .445f), Offset(w * .41f, h * .41f), w * .016f, StrokeCap.Round)
                drawLine(navy, Offset(w * .70f, h * .445f), Offset(w * .59f, h * .41f), w * .016f, StrokeCap.Round)
                poly(body1, listOf(Offset(w * .80f, h * .30f), Offset(w * .775f, h * .36f), Offset(w * .825f, h * .36f)))
                drawCircle(body1, w * .03f, Offset(w * .80f, h * .375f))
            }
            // mejillas y boca
            drawOval(Color(0x99FF8FB1), Offset(w * .24f, h * .565f), Size(w * .11f, h * .06f))
            drawOval(Color(0x99FF8FB1), Offset(w * .65f, h * .565f), Size(w * .11f, h * .06f))
            when (mood) {
                1 -> {
                    drawArc(Color(0xFFD6336C), 0f, 180f, true, Offset(w * .455f, h * .57f), Size(w * .09f, h * .075f))
                    drawCircle(Color(0xFFFF8FB1), w * .018f, Offset(w * .5f, h * .625f))
                }
                2 -> drawArc(navy, 200f, 140f, false, Offset(w * .46f, h * .62f), Size(w * .08f, h * .05f),
                    style = Stroke(w * .014f, cap = StrokeCap.Round))
                else -> drawArc(navy, 20f, 140f, false, Offset(w * .46f, h * .575f), Size(w * .08f, h * .05f),
                    style = Stroke(w * .014f, cap = StrokeCap.Round))
            }
            // accesorios por nivel
            if (level >= 3) {
                val bx = w * .30f; val by = h * .21f; val bow = Color(0xFFFF6FA5)
                poly(bow, listOf(Offset(bx, by), Offset(bx - w * .07f, by - w * .045f), Offset(bx - w * .07f, by + w * .045f)))
                poly(bow, listOf(Offset(bx, by), Offset(bx + w * .07f, by - w * .045f), Offset(bx + w * .07f, by + w * .045f)))
                drawCircle(bow, w * .022f, Offset(bx, by))
            }
            if (level >= 5) {
                poly(Color(0xFFFFC53D), listOf(Offset(w * .40f, h * .20f), Offset(w * .39f, h * .07f), Offset(w * .45f, h * .13f),
                    Offset(w * .50f, h * .05f), Offset(w * .55f, h * .13f), Offset(w * .61f, h * .07f), Offset(w * .60f, h * .20f)))
            }
            // destellos cuando está feliz
            if (mood == 1) {
                val k = .8f + .4f * bounce
                star(w * .10f, h * .22f, w * .05f * k, Color(0xFFFFD84D))
                star(w * .90f, h * .45f, w * .04f * k, Color(0xFF8BE9FF))
                star(w * .86f, h * .14f, w * .03f * k, Color.White)
            }
        }
    }
}
