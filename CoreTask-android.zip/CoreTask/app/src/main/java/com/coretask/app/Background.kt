package com.coretask.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlin.math.cos
import kotlin.math.sin

// Fondo vivo: degradado suave, manchas de color que flotan despacio y burbujitas que suben.
@Composable
fun AnimatedBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "bg")
    val phase by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "p")
    Canvas(modifier.fillMaxSize()) {
        val w = size.width; val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFFE9E4FF), Color(0xFFFFE3EE), Color(0xFFFFF0DC))))
        fun blob(color: Color, bx: Float, by: Float, r: Float, k: Float, off: Float) {
            val cx = w * (bx + 0.08f * sin(phase * k + off))
            val cy = h * (by + 0.06f * cos(phase * k + off))
            drawCircle(
                brush = Brush.radialGradient(listOf(color.copy(alpha = .55f), Color.Transparent), center = Offset(cx, cy), radius = w * r),
                radius = w * r, center = Offset(cx, cy)
            )
        }
        blob(Color(0xFF9C8CFF), .15f, .12f, .55f, 1f, 0f)
        blob(Color(0xFFFF8FB1), .90f, .30f, .50f, 1f, 2f)
        blob(Color(0xFF7FDBFF), .10f, .62f, .50f, 2f, 4f)
        blob(Color(0xFFFFC27A), .85f, .88f, .55f, 1f, 1f)
        for (i in 0 until 16) {
            val x = w * (((i * 0.137f) + 0.05f) % 1f) + w * 0.02f * sin(phase * 2f + i)
            val fall = (phase / 6.2832f * (1 + i % 3) + i * 0.17f) % 1f
            val r = w * (0.006f + (i % 4) * 0.004f)
            val col = if (i % 2 == 0) Color.White.copy(alpha = .7f) else Color(0xFFFFD1E3).copy(alpha = .8f)
            drawCircle(col, r, Offset(x, h * (1f - fall)))
        }
    }
}
